#!/bin/sh
#export MINET_DISPLAY=log
run_module.sh other_module
