#!/bin/sh
#export MINET_DISPLAY=log
run_module.sh ip_mux
