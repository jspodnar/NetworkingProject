#!/bin/sh
./test_arp
