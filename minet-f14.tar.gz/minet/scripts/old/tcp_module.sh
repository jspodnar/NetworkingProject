#!/bin/sh
export MINET_DISPLAY=xterm
run_module.sh tcp_module
